#!/bin/bash
umask 0000

LOG_DIR=/tmp/jdu_log
VAR=/var/run/jabra

HOTPLUG_PAUSE=$VAR/hotplug_pause
JDU_READY=$VAR/jdu_ready
ADD_CACHE=$VAR/addInfoReader.cache

mkdir -p $LOG_DIR

get_ini_file_path() {
    local INI_DIR_1=/setup
    local INI_DIR_2=/opt/jabra
    local INI_FILE=Jabra.ini

    if [[ -f $INI_DIR_1/$INI_FILE ]]
    then
        echo $INI_DIR_1/$INI_FILE
    elif [[ -f $INI_DIR_2/$INI_FILE ]]
    then
        echo $INI_DIR_2/$INI_FILE
    fi
}

ini_get() {
    local INI_FILE=$(get_ini_file_path)

    if [[ $INI_FILE ]]
    then
        if [[ $(which ucinitool) ]]
        then
            ucinitool -f $INI_FILE -s $1 $2
        else
            local SED_SCRIPT='/^[[:space:]]*$/d; /#/d; /\[/ { s/\[\(.*\)\]/\1/; x; d; }; /=/ { s/^[[:space:]]*//; s/[[:space:]]*=[[:space:]]*/=/; G; s/\(.*\)\n\(.*\)/\2__\1/; p; d; }'
            sed "$SED_SCRIPT" $INI_FILE | grep $1__$2= | awk -F= '{print $2}'
        fi
    fi
}

get_jdu_on_boot() {
    local res=$(ini_get "JDU" "RunOnSystemStart")
    echo ${res,,}
}

get_jdu_gui() {
    local res=$(ini_get "JDU" "ShowGui")
    echo ${res,,}
}

get_local_server_url() {
    local URL=
    local LOCAL_SERVER_XML=/setup/public/local_server_url.xml

    if [[ $(get_ini_file_path) ]]
    then
        URL=$(ini_get "JDU" "LocalServerUrl")
    fi

    if [[ $URL == ""  && -r $LOCAL_SERVER_XML ]]
    then
        URL=$(sed -n 's/.*<LocalServerUrl>\([^<]*\)<\/LocalServerUrl>.*/\1/p' $LOCAL_SERVER_XML)
    fi

    echo $URL
}

get_add_auto_post() {
    local res=$(ini_get "ADD" "AutoPost")
    echo ${res,,}
}

get_add_server_url() {
    local res=$(ini_get "ADD" "ServerUrl")
    echo ${res,,}
}
