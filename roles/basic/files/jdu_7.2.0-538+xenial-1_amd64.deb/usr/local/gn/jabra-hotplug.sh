#!/bin/bash

PROG_DIR=$(dirname $0)
. $PROG_DIR/common.sh

main() {
    if [[ -f $JDU_READY && ! -f $HOTPLUG_PAUSE  ]]
    then
        if [[ $(get_jdu_gui) == false && $1 == hiddev* ]]
        then
            echo "$PROG_DIR/addInfoReader.sh $1 >/dev/null 2>&1" | at now &>/dev/null
        elif [[ $(get_jdu_gui) == true && $1 == usb ]]
        then
            echo "$PROG_DIR/jdu.sh >/dev/null 2>&1" | at now &>/dev/null
        fi
    fi
}

main "$@"
