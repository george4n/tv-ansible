#!/bin/bash

set -e

PROG_DIR=$(dirname $0)
. $PROG_DIR/common.sh

main() {
    local SERVER_URL=$1

    if [[ $SERVER_URL == "" ]]
    then
        SERVER_URL=$(get_add_server_url)
    fi

    if [[ $SERVER_URL != "" ]]
    then
        LD_LIBRARY_PATH=$PROG_DIR $PROG_DIR/addPoster --cache=$ADD_CACHE --serverpath=$SERVER_URL
    fi
}

main "$@"
