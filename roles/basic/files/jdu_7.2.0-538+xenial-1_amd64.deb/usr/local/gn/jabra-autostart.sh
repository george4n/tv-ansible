#!/bin/bash

PROG_DIR=$(dirname $0)
. $PROG_DIR/common.sh

main() {
    xhost SI:localuser:root &>/dev/null

    if [[ $(get_jdu_on_boot) == true && $(get_jdu_gui) == true ]]
    then
        sleep 10
        NO_AT_BRIDGE=1 JDU_AUTOSTART=true $PROG_DIR/jdu.sh
    fi
}

main "$@"
