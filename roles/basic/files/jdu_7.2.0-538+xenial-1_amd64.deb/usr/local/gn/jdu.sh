#!/bin/bash

PROG_DIR=$(dirname $0)
. $PROG_DIR/common.sh

main() {

    #
    # Pause udev hotplug processing while the device is being updated
    #

    trap cleanup EXIT
    touch $HOTPLUG_PAUSE

    #
    # Prepare log collection
    #

    local FAIL_DIR=$LOG_DIR/failed
    rm -f $LOG_DIR/[^add]*.log $LOG_DIR/*.bak

    #
    # Locate wget binary
    #

    WGET=$PROG_DIR/wget

    if [[ ! -x $WGET ]]
    then
        WGET=wget
    fi

    #
    # Process optional command line argument
    #

    local XPRESS_ARCHIVE=
    get_xpress_archive "$1"

    #
    # Now start the JDU
    #

    if [[ $(get_jdu_gui) == true && ($(get_jdu_on_boot) == true || ! $JDU_AUTOSTART) ]]
    then
        run_jdu_gui
    elif [[ ! $JDU_AUTOSTART ]]
    then
        run_jdu_console
    fi

    #
    # Unpause udev hotplug processing and refresh ADD cache
    #

    rm -f $HOTPLUG_PAUSE
    $PROG_DIR/addInfoReader.sh
}

cleanup() {
    rm -f $HOTPLUG_PAUSE
}

collect_logs() {
    dmesg >$LOG_DIR/dmesg.log

    local TIMESTAMP=$(date +'%Y%m%d_%H%M%S')
    local SNAPSHOT_DIR=$FAIL_DIR/$TIMESTAMP
    local SNAPSHOT_TAR=$FAIL_DIR/$TIMESTAMP.taz

    mkdir -p $SNAPSHOT_DIR
    cp $LOG_DIR/*.log $SNAPSHOT_DIR

    cd $FAIL_DIR
    tar czf $SNAPSHOT_TAR $TIMESTAMP
    rm -rf $TIMESTAMP

    echo Detailed log information is in $SNAPSHOT_TAR
}

get_xpress_archive() {
    if [[ ${1: -4} == .zip ]]
    then
        # The user specified a .zip file -- use it instead of checking the local server
        XPRESS_ARCHIVE=$1
    else
        # Determine local server URL and download xpress archive
        if [ -n "$1" ]
        then
          LOCAL_SERVER_URL=$1
        else
          LOCAL_SERVER_URL=$(get_local_server_url)

          if [[ $LOCAL_SERVER_URL == "" ]]
          then
            echo "Could not retrieve local server URL from configuration file"
            exit 1
          fi
        fi

        $WGET -O $VAR/xpress_package_info.xml $LOCAL_SERVER_URL/xpress_package_info.xml 2>$LOG_DIR/wget.log
        if [ $? -ne 0 ]; then
            echo "Could not download xpress_package_info.xml from $LOCAL_SERVER_URL"
            collect_logs
            exit 1
        fi

        XPRESS_PACK_ZIP=`sed -n 's/.*<ZipArchive>\([^<]*\)<\/ZipArchive>.*/\1/p' $VAR/xpress_package_info.xml`

        if [ ! -e $VAR/$XPRESS_PACK_ZIP ]
        then
            echo "Downloading Xpress archive from local server.."

            # Delete old file(s) - there should be only one
            rm  -f $VAR/xpress_package_*.zip

            # Get new file
            $WGET -O $VAR/$XPRESS_PACK_ZIP $LOCAL_SERVER_URL/$XPRESS_PACK_ZIP 2>>$LOG_DIR/wget.log

            if [ $? -ne 0 ]
            then
                echo "Could not download $XPRESS_PACK_ZIP from $LOCAL_SERVER_URL"
                collect_logs
                exit 1
            fi
        fi

        XPRESS_ARCHIVE=$VAR/$XPRESS_PACK_ZIP
    fi
}

run_jdu_gui() {
    if [[ $(LD_LIBRARY_PATH=$PROG_DIR $PROG_DIR/jducheck $XPRESS_ARCHIVE) == "Update needed" ]]
    then
        { LD_LIBRARY_PATH=$PROG_DIR DISPLAY=:0 $PROG_DIR/gjdu $XPRESS_ARCHIVE ; } 2>$LOG_DIR/gjdu_shell_err.log
        STATUS=$?

        if [[ $STATUS != 0 ]]
        then
            echo "JDU failed"
            echo "Express archive file: $XPRESS_ARCHIVE"
            collect_logs
            exit $STATUS
        fi

    else
        echo jdu.sh: Everything is up-to-date
    fi
}

run_jdu_console() {
    # Run console JDU programs, first FWU, then settings
    update_firmware
    update_settings
}

update_firmware() {
    echo '--------------------------------------------------------------------------------'
    echo UPDATE FIRMWARE

    { LD_LIBRARY_PATH=$PROG_DIR $PROG_DIR/jdu_firmware -p $XPRESS_ARCHIVE ; } 2>$LOG_DIR/fwu_shell_err.log
    STATUS=$?

    if [[ $STATUS != 0 ]]
    then
        echo "Firmware update failed"
        echo "Express archive file: $XPRESS_ARCHIVE"
        collect_logs
        exit $STATUS
    fi
}

update_settings() {
    echo '--------------------------------------------------------------------------------'
    echo UPDATE SETTINGS
    { LD_LIBRARY_PATH=$PROG_DIR $PROG_DIR/jdu_settings $XPRESS_ARCHIVE ; } 2>$LOG_DIR/cfg_shell_err.log
    STATUS=$?
    echo '--------------------------------------------------------------------------------'

    if [[ $STATUS != 0 ]]
    then
        echo "Settings update failed"
        echo "Express archive file: $XPRESS_ARCHIVE"
        collect_logs
        exit $STATUS
    fi
}

gui_jdu() {
    { LD_LIBRARY_PATH=$PROG_DIR $PROG_DIR/gjdu $XPRESS_ARCHIVE ; } 2>$LOG_DIR/gjdu_shell_err.log
}

main "$@"