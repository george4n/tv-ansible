#!/bin/bash

PROG_DIR=$(dirname $0)
. $PROG_DIR/common.sh

main() {
    local LOG=$LOG_DIR/addInfoReader.log

    if [[ -f /tmp/add.disable ]]
    then
        echo ADD has been disabled >>$LOG
        exit 0
    fi

    if [[ -f $JDU_READY && ! -f $HOTPLUG_PAUSE ]]
    then
        LD_LIBRARY_PATH=$PROG_DIR $PROG_DIR/addInfoReader --cache=$ADD_CACHE $1

        local AUTO_POST=$(get_add_auto_post)
        local SERVER_URL=$(get_add_server_url)

        if [[ $AUTO_POST == true && $SERVER_URL ]]
        then
            echo ADD AutoPost is active, URL: $SERVER_URL
            echo AUTO POST to $SERVER_URL >>$LOG
            echo CACHE: >>$LOG
            echo --------------------------------------------------- >>$LOG
            cat $ADD_CACHE >>$LOG
            echo --------------------------------------------------- >>$LOG
            $PROG_DIR/addPoster.sh $SERVER_URL 2>&1 | tee -a $LOG
        fi
    fi
}

main "$@"
